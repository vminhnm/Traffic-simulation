package core.driver;

import core.rule.TrafficRuleEvaluator;
import core.simulation.SimulationWorld;
import core.vehicle.PriorityVehicle;
import core.vehicle.Vehicle;

/**
 * <b>Lái xe khẩn cấp</b> — dành riêng cho {@link core.vehicle.PriorityVehicle}.
 *
 * <h2>Đặc điểm</h2>
 * <ul>
 *   <li><b>Bỏ qua hoàn toàn đèn đỏ / vàng</b> — xe ưu tiên có quyền đi.</li>
 *   <li>Tốc độ = {@code maxSpeed × 1.4}.</li>
 *   <li>Khi có xe đang chắn thẳng đường ({@code gap < CRITICAL_GAP}),
 *       giảm tốc nhẹ thay vì phanh gấp — tránh đâm nhưng không dừng.</li>
 *   <li>Tín hiệu EMERGENCY_PASS thông báo cho SimulationEngine biết
 *       cần kích hoạt logic "xe thường tránh đường" cho vùng lân cận.</li>
 * </ul>
 */
public class EmergencyDriver implements DriverBehavior {

    private static final TrafficRuleEvaluator RULES         = new TrafficRuleEvaluator();
    private static final double               SPEED_FACTOR  = 1.4;
    /** Khoảng cách tối thiểu (px) trước khi bắt đầu giảm tốc nhẹ. */
    private static final double               CRITICAL_GAP  = 20.0;

    @Override
    public DrivingDecision decide(Vehicle vehicle, SimulationWorld world) {

        if (vehicle instanceof PriorityVehicle priorityVehicle
                && !priorityVehicle.isSirenActive()) {
            if (RULES.mustStopAtRedLight(vehicle, world)) {
                return DrivingDecision.stop();
            }

            double gap = RULES.gapToObstacleAhead(vehicle, world);
            if (gap >= 0) {
            double speed = vehicle.getSpeed();
            double brakingDistance = (speed * speed) / (vehicle.getAcceleration() * 2);
            double safeGap = vehicle.getLength() * 0.5 + brakingDistance + 10;

            if (gap < safeGap) {
                double ratio = Math.max(0, gap / safeGap);
                double targetSpeed = vehicle.getMaxSpeed() * ratio * 0.4;
                return DrivingDecision.brake(targetSpeed);
            }
}
            double safeDistance = vehicle.getLength() * 1.5 + 15;
            if (gap >= 0 && gap < safeDistance) {
                double ratio = Math.max(0, gap / safeDistance);
                return DrivingDecision.brake(vehicle.getMaxSpeed() * ratio * 0.6);
            }

            return DrivingDecision.accelerate(vehicle.getMaxSpeed());
        }

        // ── Return to lane centre if no longer yielding ──────────────────
        // Only drift back if the lane ahead is clear (no vehicle in merge path)
        if (vehicle.getLateralOffset() != 0 
                && !RULES.shouldYieldToPriorityVehicle(vehicle, world)) {
            
            if (isMergePathClear(vehicle, world)) {
                // Let normal STOP/BRAKE/ACCELERATE handle movement,
                // applyDecision will drift lateralOffset back.
                // No special action needed — fall through.
            } else {
                // Hold current lateral position: return a stop/brake that won't drift
                // Use YIELD action to freeze in place (it does not drift back)
                return DrivingDecision.yield(); // holds speed at 0 if already stopped
            }
        }

        // Kiểm tra khoảng trống vật lý phía trước (xe thường chưa kịp tránh)
        double gap = RULES.gapToFrontVehicle(vehicle, world);

        if (gap >= 0) {
            double speed = vehicle.getSpeed();
            // Braking uses acceleration * 2 (see Vehicle.applyDecision BRAKE branch)
            double brakingDistance = (speed * speed) / (vehicle.getAcceleration() * 2);
            double safeGap = vehicle.getLength() * 0.5 + brakingDistance + 10;

            if (gap < safeGap) {
                // Proportional brake — stops fully if gap is very small
                double ratio = Math.max(0, gap / safeGap);
                double targetSpeed = vehicle.getMaxSpeed() * ratio * 0.4;
                return DrivingDecision.brake(targetSpeed);
            }
        }

        return DrivingDecision.emergencyPass(vehicle.getMaxSpeed() * SPEED_FACTOR);
    }

    private boolean isMergePathClear(Vehicle vehicle, SimulationWorld world) {
        // Check if any vehicle is within ~1.5 car-lengths laterally and 
        // longitudinally close enough to be a collision risk
        double myOffset = vehicle.getLateralOffset();
        double targetOffset = 0.0; // merging toward centre

        return world.getVehicles().stream()
            .filter(other -> other != vehicle && !other.isPriorityVehicle())
            .noneMatch(other -> {
                // Must be on same path/direction
                boolean samePath = other.getPath().getEntryArm()
                    .equals(vehicle.getPath().getEntryArm());
                if (!samePath) return false;
                
                double lateralDiff = Math.abs(other.getLateralOffset() - targetOffset);
                double longDist = vehicle.getPosition().distanceTo(other.getPosition());
                
                // Collision risk: close laterally to merge target AND close longitudinally
                return lateralDiff < vehicle.getWidth() * 1.5 
                    && longDist < vehicle.getLength() * 3.0;
            });
    }

    @Override
    public String getStyleName() { return "Emergency"; }
}
